# Course title: CPNT 262 - Web Client and Server Programming
## Project: Final Project - Multi-page Website with Gallery;
  ### Author name: Kaleb Berhane;
  - [Repo Link](https://github.com/Kaleb-cpu/CPNT262-Final-Project)
  - [live Site](https://cpnt-262-final-project.vercel.app/)
  ### Attributions: 
   * [Tony's Class-Refractor Example](https://github.com/sait-wbdv/w23-refactor-example)
   * [Hover Effects](https://css-tricks.com/almanac/properties/t/transition/)
   * [coding lab](https://www.codinglabweb.com/2022/11/about-us-page-html-css.html)
   * [Sveltekit Material UI](https://sveltematerialui.com/INSTALL.md)
   ### Third party Library: Tailwind used as well as Sveltekit Material UI 