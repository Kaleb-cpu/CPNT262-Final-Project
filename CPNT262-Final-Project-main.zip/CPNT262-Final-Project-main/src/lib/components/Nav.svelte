<nav>
	<a href="/">Home</a>
	<a href="./gallery">Gallery</a>
	<a href="./about">About</a>
	<a href="./contact">Contact</a>
</nav>
