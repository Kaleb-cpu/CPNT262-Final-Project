<footer>
	<p>TERMS OF USE</p>
	<p>PRIVACY AND POLICY</p>
	<p>&copy; Kaleb Berhane. All rights reserved</p>
</footer>
